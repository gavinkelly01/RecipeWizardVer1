package com.example.test;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.test.R;
import com.example.test.Recipe;
import com.squareup.picasso.Picasso;

import java.util.List;

public class RecipeDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_details);

        // Get the selected recipe from the intent extra
        Recipe selectedRecipe = getIntent().getParcelableExtra("selected_recipe");

        if (selectedRecipe != null) {
            // Set the recipe image
            ImageView recipeImage = findViewById(R.id.recipe_image);
            Picasso.get().load(selectedRecipe.getImageUrl()).into(recipeImage);

            // Set the recipe title
            TextView recipeTitle = findViewById(R.id.recipe_title);
            recipeTitle.setText(selectedRecipe.getTitle());

            // Set the recipe ingredients
            TextView recipeIngredients = findViewById(R.id.recipe_ingredients);
            recipeIngredients.setText(listToString(selectedRecipe.getIngredients()));

            // Set the recipe instructions
            TextView recipeInstructions = findViewById(R.id.recipe_instructions);
            recipeInstructions.setText(listToString(selectedRecipe.getInstructions()));
        } else {
            Toast.makeText(this, "Selected recipe is null", Toast.LENGTH_SHORT).show();
        }
    }

    private String listToString(List<String> list) {
        StringBuilder sb = new StringBuilder();
        for (String item : list) {
            sb.append(item).append("\n");
        }
        return sb.toString();
    }
}



