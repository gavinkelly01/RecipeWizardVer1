package com.example.test;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.squareup.picasso.Picasso;

import java.util.List;

public class RecipeDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_details);

        // Get the selected recipe from the intent extra
        Recipe selectedRecipe = getIntent().getParcelableExtra("selected_recipe");

        if (selectedRecipe != null) {
            // Set the recipe image
            ImageView recipeImage = findViewById(R.id.recipe_image);
            Picasso.get().load(selectedRecipe.getImageUrl()).into(recipeImage);

            // Set the recipe title
            TextView recipeTitle = findViewById(R.id.recipe_title);
            recipeTitle.setText(selectedRecipe.getTitle());


            // Set the recipe instructions
        } else {
            Toast.makeText(this, "Selected recipe is null", Toast.LENGTH_SHORT).show();
        }
        String[] ingredient = {
                "3 tbsp olive oil",
                "2 red onions, sliced",
                "2 red peppers, sliced",
                "3 red chillies, 2 deseeded and chopped, 1 sliced",
                "small bunch coriander, stalks finely chopped, leaves roughly chopped - plus extra to serve (optional)",
                "2 garlic cloves, crushed",
                "1 tbsp ground coriander",
                "1 tbsp cumin seeds",
                "6 skinless chicken breasts, cut into small chunks",
                "415g can refried beans (we used Discovery)",
                "198g can sweetcorn, drained",
                "700ml bottle passata",
                "1 tsp golden caster sugar",
                "10 tortillas",
                "2 x 142ml pots soured cream",
                "200g cheddar, grated"
        };

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, ingredient);
        ListView listView = findViewById(R.id.recipe_ingredients);
        listView.setAdapter(adapter);

    }



    private String listToString(List<String> list) {
        StringBuilder sb = new StringBuilder();
        for (String item : list) {
            sb.append(item).append("\n");
        }
        return sb.toString();
    }
}




