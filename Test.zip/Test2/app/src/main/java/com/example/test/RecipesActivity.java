package com.example.test;

import android.os.Bundle;
import android.content.Context;
import android.widget.SearchView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class RecipesActivity extends AppCompatActivity {

    private static final String API_KEY = "20aafda003974ac882f1eea7d25290ab";
    private RecyclerView recyclerView;
    private SearchView searchView;
    private RecipeAdapter recipeAdapter;
    private List<Recipe> recipes = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipes);

        recyclerView = findViewById(R.id.recycler_view);
        searchView = findViewById(R.id.search_view);
        recipeAdapter = new RecipeAdapter(recipes, this);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(recipeAdapter);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                searchRecipes(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });
    }

    private void searchRecipes(String query) {
        String url = "https://api.spoonacular.com/recipes/search?apiKey=" + API_KEY + "&query=" + query;

        RequestQueue queue = Volley.newRequestQueue(this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(url, null,
                response -> {
                    recipes.clear();
                    try {
                        JSONArray results = response.getJSONArray("results");
                        for (int i = 0; i < results.length(); i++) {
                            JSONObject result = results.getJSONObject(i);
                            int id = result.getInt("id");
                            String title = result.getString("title");
                            String imageUrl = result.getString("image");
                            recipes.add(new Recipe(id, title, imageUrl));
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    recipeAdapter.notifyDataSetChanged();
                },
                error -> error.printStackTrace());
        queue.add(jsonObjectRequest);
    }
}
